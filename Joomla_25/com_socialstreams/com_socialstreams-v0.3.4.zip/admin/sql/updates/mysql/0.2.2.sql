-- -----------------------------------------------------
-- Version 0.2.2 updates
-- -----------------------------------------------------
ALTER TABLE `#__ss_auth` CHANGE COLUMN `profile_id` `profile_id` INT(11) NOT NULL DEFAULT 0  ;
