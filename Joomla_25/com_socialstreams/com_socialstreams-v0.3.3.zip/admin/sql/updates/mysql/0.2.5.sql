-- -----------------------------------------------------
-- Version 0.2.5 updates
-- -----------------------------------------------------
ALTER TABLE `#__ss_auth` ADD COLUMN `access_token_secret` VARCHAR(255) default '' ;