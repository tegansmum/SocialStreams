-- ----------------------------------------------------
-- Drop all the tables associated with this component
-- ----------------------------------------------------
DROP TABLE IF EXISTS `#__ss_connections`;
DROP TABLE IF EXISTS `#__ss_item_meta`;
DROP TABLE IF EXISTS `#__ss_items`;
DROP TABLE IF EXISTS `#__ss_profiles`;
DROP TABLE IF EXISTS `#__ss_auth`;