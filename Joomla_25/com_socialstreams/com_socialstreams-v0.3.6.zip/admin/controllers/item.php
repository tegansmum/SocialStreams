<?php

defined('_JEXEC') or die('Restricted access');
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

// import Joomla controllerform library
jimport('joomla.application.component.controllerform');

/**
 * Single default controller 
 */
class SocialStreamsControllerItem extends JControllerForm {

}

?>
