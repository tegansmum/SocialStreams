<?php
defined('_JEXEC') or die('Restricted Access');
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<tr>
	<td colspan="8"><?php echo $this->pagination->getListFooter(); ?></td>
</tr>