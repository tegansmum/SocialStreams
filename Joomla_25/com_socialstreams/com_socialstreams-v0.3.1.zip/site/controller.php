<?php

// No direct access
defined('_JEXEC') or die('Restricted access');
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
// import Joomla controller library
jimport('joomla.application.component.controller');

/**
 * Description of SocialstreamsController
 *
 * @author stuart
 */
class SocialStreamsController extends JController {

    private $networks = array();

    function __construct($default = array()) {
        parent::__construct($default);

        // use the same models as the back-end
        $path = JPATH_COMPONENT_ADMINISTRATOR . DS . 'models';
        $this->addModelPath($path);
        $jparams = JComponentHelper::getParams('com_socialstreams');

        $this->registerTask('cycle', 'cycleCaches');
        $this->registerTask('count', 'updateCount');
        $this->registerTask('refresh', 'refreshCache');
    }

    /**
     * Method to display a view.
     *
     * @param	boolean			If true, the view output will be cached
     * @param	array			An array of safe url parameters and their variable types, for valid values see {@link JFilterInput::clean()}.
     *
     * @return	JController		This object to support chaining.
     * @since	1.5
     */
    public function display($cachable = false, $safeurlparams = array()) {
        $cachable = true;
        parent::display($cachable, $safeurlparams);

        return $this;
    }

    public function refreshCache() {
        jimport('joomla.error.log');
        $errorLog = & JLog::getInstance();
        $errorLog->addEntry(array('status' => 'DEBUG', 'comment' => 'SocialStreamsController::refreshCache'));
        JLoader::import('components.com_socialstreams.helpers.socialstreams', JPATH_ADMINISTRATOR);

        // Check for request forgeries
        JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

        $jinput = JFactory::getApplication()->input;
        $type = $jinput->get('type', NULL, 'STRING');

        if (!$type || $type = 'profiles') {
            // Refresh Profiles
            $model = $this->getModel('Profile', 'SocialStreamsModel');
            $model->refresh();
        }

        if (!$type || $type = 'items') {
            // Refresh Items
            $model = $this->getModel('Item', 'SocialStreamsModel');
            $model->refresh();
        }
        if ($type = 'profiles')
            $this->setRedirect('index.php?option=com_socialstreams&view=profiles&format=json');
        else
            $this->setRedirect('index.php?option=com_socialstreams&view=items&format=json');
    }

    function cycleCaches() {
        JLoader::import('components.com_socialstreams.helpers.socialstreams', JPATH_ADMINISTRATOR);
        $networks = SocialStreamsHelper::getNetworks();
        foreach ($networks as $network) {
            
        }
        global $mainframe;
        $cachetypes = array('profile' => 0, 'item' => 0);
        $registry = & JFactory::getConfig();
        $jparams = JComponentHelper::getParams('com_socialstreams');
        $now = time();
        // Run updates on each cache type
        foreach ($cachetypes as $cachetype => &$cache) {
            $model = $this->getModel($cachetype . 'cache');
            $period = intval($jparams->get($cachetype . '_period'), 10);
            $oldestcachedate = $now + $period;
            $oldestcache = '';
            // Get the names of the active social networks
            $networks = array_keys($this->networks);
            // Find the oldest cache
            foreach ($networks as $network) {
                $lastcachedate = $registry->getValue('socialstreams.' . $network . '_' . $cachetype . '_next_cache_date', 0);

                if ($lastcachedate < $oldestcachedate) {
                    $oldestcachedate = $lastcachedate;
                    $oldestcache = $network;
                }
            }
            // Does the oldest cache need renewing?
            if ($oldestcachedate < $now) {
                $cache = $model->cycleCaches($oldestcache);
                // Update the next cache date
                foreach ($cache as $network => $result)
                    if ($result)
                        $registry->setValue('socialstreams.' . $network . '_' . $cachetype . '_next_cache_date', $now + $period);
            }
        }
        // We're not going to hand back to the component file, so we'd better store the registry now
        $ini = $registry->toString('INI', 'socialstreams');
        // save INI file
        jimport('joomla.filesystem.file');
        JFile::write(JPATH_COMPONENT_ADMINISTRATOR . DS . 'socialstreams.ini', $ini);
        // Get the document object.
        $document = & JFactory::getDocument();
        // Set the MIME type for JSON output.
        $document->setMimeEncoding('application/json');
        // Change the suggested filename.
        JResponse::setHeader('Content-Disposition', 'attachment;filename="' . $network . '.json"');
        // Output the JSON data.
        echo json_encode($cachetypes);
        $mainframe->close();
    }

    function updateCount() {
        global $mainframe;
        $now = time();
        $networks = array(
            'facebook' => 1,
            'twitter' => 1,
            'stumbleupon' => 1
        );
        $url = urldecode(JRequest::getVar('url', ''));
        $articleid = JRequest::getVar('articleid', '');
        $catid = JRequest::getVar('catid', '');
        $frontmodel = $this->getModel('frontmentioncache');
        $mentions = $frontmodel->getUrl($url);
        foreach ($mentions as $mention)
            if ($mention->date > $now - 86400)
                unset($networks[$mention->network]);
        if (count($networks)) {
            $adminmodel = $this->getModel('mentioncache');
            $id = empty($catid) ? $articleid : $catid;
            $adminmodel->cycleCache($url, array_keys($networks), $id);
        }
        // Get the document object.
        $document = & JFactory::getDocument();
        // Set the MIME type for JSON output.
        $document->setMimeEncoding('application/json');
        // Change the suggested filename.
        JResponse::setHeader('Content-Disposition', 'attachment;filename="' . $network . '.json"');
        // Output the JSON data.
        echo json_encode($cachetypes);
        $mainframe->close();
    }

}

?>
