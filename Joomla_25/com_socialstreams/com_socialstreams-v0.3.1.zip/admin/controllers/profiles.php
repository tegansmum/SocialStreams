<?php

defined('_JEXEC') or die('Restricted access');
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

// import Joomla controlleradmin library
jimport('joomla.application.component.controlleradmin');

/**
 * Attractions Controller 
 */
class SocialStreamsControllerProfiles extends JControllerAdmin {

    /**
     * Proxy for getModel.
     * @since	2.5
     */
    public function getModel($name = 'Profile', $prefix = 'SocialStreamsModel') {
        $model = parent::getModel($name, $prefix, array('ignore_request' => true));
        return $model;
    }

    public function refreshcache() {
        jimport('joomla.error.log');
        $errorLog = & JLog::getInstance();
        $errorLog->addEntry(array('status' => 'DEBUG', 'comment' => 'SocialStreamsControllerProfiles::refreshcache'));
        JLoader::import('components.com_socialstreams.helpers.socialstreams', JPATH_ADMINISTRATOR);

        // Check for request forgeries
        JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

        // Initialise variables.
        $user = JFactory::getUser();

        if (!$user->authorise('core.edit', 'com_socialstreams.profile')) {
            JError::raiseNotice(403, JText::_('You are not allowed to update the Profile Cache'));
        } else {
            $jinput = JFactory::getApplication()->input;
            $force = $jinput->get('force', TRUE, 'BOOLEAN');
            $model = $this->getModel();
            $model->refresh($force);
//            $db = JFactory::getDBO();
//            $query = $db->getQuery(true);
//            $query->select('network, clientid');
//            $query->from('#__ss_auth');
//            $query->where('state = 1 AND expires > NOW()');
//            $db->setQuery($query);
//            $networks = $db->loadAssocList();
////            $errorLog->addEntry(array('status' => 'DEBUG', 'comment' => 'Networks -> ' . print_r($networks, true)));
//            foreach ($networks as $network) {
//
//                if ($api = SocialStreamsHelper::getApi($network['network'], $network['clientid'])) {
////                    $errorLog->addEntry(array('status' => 'DEBUG', 'comment' => 'API -> ' . print_r($api, true)));
//                    if ($profile = $api->getProfile($network['clientid'])) {
////                        $errorLog->addEntry(array('status' => 'DEBUG', 'comment' => 'Profile -> ' . print_r($profile->toArray(), true)));
//                        $model = $this->getModel();
//                        if (!$model->save($profile->toArray()))
//                            JError::raiseWarning('500', 'Failed to Save Profile ' . $profile->name . ' for Client ID ' . $network['clientid'] . ' on Network ' . $network['network']);
//                    }
//                    if ($connections = $api->getConnectedProfiles($network['clientid'])) {
//                        foreach ($connections as $profile) {
//                            $model = $this->getModel();
//                            if (!$model->save($profile->toArray()))
//                                JError::raiseWarning('500', 'Failed to Save Profile ' . $profile->name . ' for Client ID ' . $network['clientid'] . ' on Network ' . $network['network']);
//                        }
//                    }
//                }
//            }
        }

        $this->setRedirect('index.php?option=com_socialstreams&view=profiles');
    }

}

?>
