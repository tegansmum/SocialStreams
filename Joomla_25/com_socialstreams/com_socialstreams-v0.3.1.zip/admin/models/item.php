<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

// import the Joomla modellist library
jimport('joomla.application.component.modeladmin');

/**
 * Visit Manager List Model
 */
class SocialStreamsModelItem extends JModelAdmin {

    /**
     * Method to save the form data.
     *
     * @param   array  $data  The form data.
     *
     * @return  boolean  True on success, False on error.
     *
     * @since   11.1
     */
    public function save($data) {
        jimport('joomla.error.log');
        $errorLog = & JLog::getInstance();
        $errorLog->addEntry(array('status' => 'DEBUG', 'comment' => 'SocialStreamsModelItem::save'));
        $errorLog->addEntry(array('status' => 'DEBUG', 'comment' => print_r($data, true)));
        if (is_object($data['profile'])) {
            // Find the associated Profile
            $profile = $this->getTable('ssprofiles');
            if ($profile->load(array('network' => $data['profile']->network, 'networkid' => $data['profile']->networkid))) {
                $key = $profile->getKeyName();
                $data['profile_id'] = $profile->$key;
            }
        }
        $table = $this->getTable();
        $key = $table->getKeyName();
        $this->setState($this->getName() . '.id', 0);
        $pk = (!empty($data[$key])) ? $data[$key] : (int) $this->getState($this->getName() . '.id');
        // Try to find an existing record
        if ($pk > 0) {
            $data[$key] = $pk;
        } elseif (isset($data['network']) && isset($data['networkid'])) {
            if ($table->load(array('network' => $data['network'], 'networkid' => $data['networkid'])))
                $data[$key] = $table->$key;
        }

        if (!parent::save($data))
            return false;

        return $this->getState($this->getName() . '.id');
    }

    /**
     * Returns a reference to the a Table object, always creating it.
     *
     * @param	type	The table type to instantiate
     * @param	string	A prefix for the table class name. Optional.
     * @param	array	Configuration array for model. Optional.
     * @return	JTable	A database object
     * @since	1.6
     */
    public function getTable($type = 'ssitems', $prefix = 'SocialStreamsTable', $config = array()) {
        return JTable::getInstance($type, $prefix, $config);
    }

    /**
     * Prepare and sanitise the table data prior to saving.
     *
     * @param   JTable  $table  A reference to a JTable object.
     *
     * @return  void
     *
     * @since   12.2
     */
    protected function prepareTable(&$table) {
        jimport('joomla.error.log');
        $errorLog = & JLog::getInstance();
        $errorLog->addEntry(array('status' => 'DEBUG', 'comment' => 'SocialStreamsModelItem::prepareTable'));
        if (empty($table->id))
            $table->created = JFactory::getDate(time())->toMySQL();
        $jparams = JComponentHelper::getParams('com_socialstreams');
        $table->expires = JFactory::getDate(time() + $jparams->get('item_period'))->toMySQL();
        $errorLog->addEntry(array('status' => 'DEBUG', 'comment' => print_r(get_object_vars($table), true)));
    }

    /**
     * Method to get the record form.
     *
     * @param	array	$data		Data for the form.
     * @param	boolean	$loadData	True if the form is to load its own data (default case), false if not.
     * @return	mixed	A JForm object on success, false on failure
     * @since	1.6
     */
    public function getForm($data = array(), $loadData = true) {
        // Get the form.
        $form = $this->loadForm('com_socialstreams.item', 'item', array('control' => 'jform', 'load_data' => $loadData));
        if (empty($form)) {
            return false;
        }

        return $form;
    }

    /**
     * Method to get the data that should be injected in the form.
     *
     * @return	mixed	The data for the form.
     * @since	1.6
     */
    protected function loadFormData() {
        // Check the session for previously entered form data.
        $data = JFactory::getApplication()->getUserState('com_socialstreams.edit.item.data', array());

        if (empty($data)) {
            $data = $this->getItem();
        }

        return $data;
    }

    function refresh($force = false) {
        jimport('joomla.error.log');
        $errorLog = & JLog::getInstance();
        $errorLog->addEntry(array('status' => 'DEBUG', 'comment' => 'SocialStreamsModelItem::refresh'));
        JLoader::import('components.com_socialstreams.helpers.socialstreams', JPATH_ADMINISTRATOR);
        // Load the authenticated networks into an array and randomise it
        $db = $this->getDbo();
        $query = $db->getQuery(true);
        $query->select('id, network, clientid');
        $query->from('#__ss_auth');
        $query->where('state = 1 AND expires > NOW()');
        $db->setQuery($query);
        $networks = $db->loadAssocList();
        shuffle($networks);
        // Work through the networks looking for out of date items
        foreach ($networks as $network) {
            $fetch = false;
            // If there are no items for this network then it will need fetching
            $query = $db->getQuery(true);
            $query->select('COUNT(id)');
            $query->from('#__ss_items');
            $query->where('client_id = "' . $network['id'] . '"');
            $db->setQuery($query);
            if (!$db->loadResult())
                $fetch = true;
            $errorLog->addEntry(array('status' => 'DEBUG', 'comment' => $network['network'] . ' Exists: ' . ($fetch ? 'yes' : 'no')));
            if (!$fetch && !$force) {
                // If items existed for this network, then look for out of date ones
                $query = $db->getQuery(true);
                $query->select('COUNT(id)');
                $query->from('#__ss_items');
                $query->where('client_id = "' . $network['id'] . '"');
                $query->where('expires < NOW()');
                $db->setQuery($query);
                if ($db->loadResult())
                    $fetch = true;
                $errorLog->addEntry(array('status' => 'DEBUG', 'comment' => $network['network'] . ' Expired: ' . ($fetch ? 'yes' : 'no')));
            }
            if ($fetch) {

                if ($api = SocialStreamsHelper::getApi($network['network'], $network['clientid'])) {
//                    $errorLog->addEntry(array('status' => 'DEBUG', 'comment' => 'API -> ' . print_r($api, true)));
                    if ($items = $api->getItems($network['clientid'])) {
                        foreach ($items as $item) {
                            $save_item = $item->store();
                            $save_item['client_id'] = $network['id'];
                            if (!$this->save($save_item))
                                JError::raiseWarning('500', 'Failed to Save Item ' . $item->networkid . ' for Client ID ' . $network['clientid'] . ' on Network ' . $network['network']);
                        }
                    }

                    $this->clearExpired($network['network'], $network['id']);
                }
                if (!$force)
                    break;
            }
        }
        return true;
    }

    function clearExpired($network, $user = false) {
        $db = & JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('id');
        $query->from('#__ss_items');
        $query->where($db->nameQuote('network') . ' = ' . $db->Quote($network));
        if ($user)
            $query->where($db->nameQuote('client_id') . ' = ' . $user . ' OR ' . $db->nameQuote('client_id') . ' = 0');
        $query->where($db->nameQuote('expires') . ' < NOW()');
        $db->setQuery($query);
        if ($result = $db->loadResultArray())
            if ($this->delete($result))
                return count($result);
        return false;
    }

}

?>
